package com.example.autoanswer

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ScreenService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var overlay: TextView
    private lateinit var wm: WindowManager
    private var apiKey = ""
    private var lastText = ""
    @Volatile private var busy = false
    private var running = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        val ch = "scr"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "AutoAnswer", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch).setContentTitle("AutoAnswer работает")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        apiKey = intent.getStringExtra("key") ?: ""
        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent.getIntExtra("code", Activity.RESULT_OK), data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)

        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        setupOverlay()
        loop()
        return START_NOT_STICKY
    }

    private fun setupOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            setBackgroundColor(Color.argb(210, 0, 0, 0)); setPadding(32, 24, 32, 24)
            text = "Жду вопрос…"
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        wm.addView(overlay, lp)
    }

    private fun loop() {
        if (!running) return
        if (!busy) {
            overlay.visibility = View.INVISIBLE            // чтобы не читать собственный ответ
            main.postDelayed({
                val bmp = grab()
                overlay.visibility = View.VISIBLE
                if (bmp != null) recognize(bmp)
            }, 150)
        }
        main.postDelayed({ loop() }, 2000)
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        img.use {
            val p = it.planes[0]
            val rowPad = p.rowStride - p.pixelStride * it.width
            val full = Bitmap.createBitmap(it.width + rowPad / p.pixelStride, it.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            return Bitmap.createBitmap(full, 0, 0, it.width, it.height)
        }
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0)).addOnSuccessListener { r ->
            val text = r.text.trim()
            if (text.length < 20 || text == lastText) return@addOnSuccessListener
            lastText = text
            busy = true
            overlay.text = "Думаю…"
            io.execute {
                val answer = try { ask(text) } catch (e: Exception) { "Ошибка: ${e.message}" }
                main.post { overlay.text = answer; busy = false }
            }
        }
    }

    private fun ask(screenText: String): String {
        val body = JSONObject()
            .put("model", "claude-sonnet-4-6").put("max_tokens", 400)
            .put("system", "Ниже текст с экрана телефона. Если там есть вопрос или задание — дай краткий ответ (номер/слово/число и одна строка пояснения). Если вопроса нет — ответь «—». Отвечай на языке вопроса.")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", screenText)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", apiKey)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) return "API ${c.responseCode}: $resp".take(300)
        return JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { wm.removeView(overlay) } catch (_: Exception) {}
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
